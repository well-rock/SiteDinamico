<?php

return [
	'titulo'=>'Site Dinâmico',
	'descricao'=>'Descrição do Site Dinâmico',
	'imagem'=>'imagem do site'

];