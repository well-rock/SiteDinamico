<h2>Contato do Site</h2>
<p>Nome: <?php echo e($request['nome']); ?></p>
<p>E-mail: <?php echo e($request['email']); ?></p>
<p>Mensagem: <?php echo e($request['mensagem']); ?></p>