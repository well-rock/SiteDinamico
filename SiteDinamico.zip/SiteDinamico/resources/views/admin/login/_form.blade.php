
<div class="input-field">
	<input type="text" name="email" class="validate">
	<label>E-mail</label>
</div>
<div class="input-field">
	<input type="password" name="password" class="validate">
	<label>Senha</label>
</div>