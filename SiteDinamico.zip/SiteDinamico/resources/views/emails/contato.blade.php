<h2>Contato do Site</h2>
<p>Nome: {{ $request['nome'] }}</p>
<p>E-mail: {{ $request['email'] }}</p>
<p>Mensagem: {{ $request['mensagem'] }}</p>